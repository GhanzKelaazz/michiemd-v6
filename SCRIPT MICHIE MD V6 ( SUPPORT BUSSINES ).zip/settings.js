const fs = require('fs');
const chalk = require('chalk');

//~~~~~~~~~~~~< Ghanniie >~~~~~~~~~~~~\\

global.owner = ['6289523122764'] //['628','628'] 2 owner
global.packname = '𐙚'
global.author = 'ghanniiee'
global.botname = 'Michie MD'
global.listprefix = ['+','!','.']
global.listv = ['•','●','■','✿','▲','➩','➢','➣','➤','✦','✧','△','❀','○','□','♤','♡','◇','♧','々','〆']
global.tempatDB = 'database.json' // Taruh url mongodb di sini jika menggunakan mongodb. Format : 'mongodb+srv://...'
global.tempatStore = 'baileys_store.json'
global.pairing_code = true
global.number_bot = '6289510783629' // Kalo pake panel bisa masukin nomer di sini, jika belum ambil session. Format : '628xx'

global.fake = {
	anonim: 'https://telegra.ph/file/95670d63378f7f4210f03.png',
	thumbnailUrl: 'https://telegra.ph/file/fe4843a1261fc414542c4.jpg',
	thumbnail: fs.readFileSync('./src/media/michie.png'),
	docs: fs.readFileSync('./src/media/fake.pdf'),
	listfakedocs: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/pdf'],
}

global.my = {
	yt: 'ghaniiey',
	gh: '-',
	gc: 'https://chat.whatsapp.com/EDHKhmPTGgNCT5ziYE7WDs',
	ch: '120363401581149765@newsletter',
}

global.limit = {
	free: 70,
	premium: 9999,
	vip: 9999
}

global.money= {
	free: 10000,
	premium: 1000000,
	vip: 10000000
}

global.mess = {
	key: 'Apikey mu telah habis silahkan kunjungi\nhttps://ghann-official-store.vercel.app',
	owner: '*Fitur Ini Khusus Owner Bot*',
	admin: '*Fitur ini khusus admin*',
	botAdmin: '_*Belum bisa bg soalnya bot bukan admin*_',
	group: 'Gunakan Di Group!',
	private: 'Gunakan Di Privat Chat',
	limit: 'Limit Anda Telah Habis!\nMau Nambah limit?\n.gamemenu\n.buy\n.rampok\n.begal',
	prem: 'Khusus User Premium!',
	wait: 'Loading🕒...',
	error: 'Error!',
	done: 'Nih'
}

global.APIs = {
	hitori: 'https://api.hitori.pw',
}
global.APIKeys = {
	'https://api.hitori.pw': 'htrkey-77eb83c0eeb39d40',
	geminiApikey: ['AIzaSyD0lkGz6ZhKi_MHSSmJcCX3wXoDZhELPaQ','AIzaSyDnBPd_EhBfr73NssnThVQZYiKZVhGZewU','AIzaSyA94OZD-0V4quRbzPb2j75AuzSblPHE75M','AIzaSyB5aTYbUg2VQ0oXr5hdJPN8AyLJcmM84-A','AIzaSyB1xYZ2YImnBdi2Bh-If_8lj6rvSkabqlA']
}

// Michie MD

global.badWords = ['tolol','goblok','asu','pantek','kampret','ngentot','jancok','kontol','memek','lonte']


//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});